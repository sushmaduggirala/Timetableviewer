{  
  alert("Login Succesfull");
  window.location.replace("wa.html");
  
  }

    